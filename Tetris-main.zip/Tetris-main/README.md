# Tetris

Tetris game based on OpenGL which includes GLFW, GLEW.

## Installation

Use the following commands for debian based system.

```bash
cd Desktop/
git clone https://github.com/Khushiyant/Tetris.git
cd Tetris/

chmod +x requiremets.sh
./requiremets.sh
```
or

Just run `run.bat` for windows system, after cloning

# About
## Code Structure
The game logic is implemented in `Tetromino.cpp`. The exact game rules and mechanics are used.

`Board.cpp` represents the geometric state of the board. It checks whether tile have collided, or when to add tile.

`Constants.h` stores all the fixed values required throughout the game such as speed increase, tile color, position etc;

`Keyboard.cpp` handles all the input, display related problems

`Tetris.cpp` is just a master calling function

Building
-------- 
You can compile build files in your system by installing cmake and using following commands:
```bash
cd path/to/Tetris-clone/
cd tetris && make 
```

Make sure you install `GLFW3`,`GLEW`, `GLM` and `freetype2` correctly,if there is error `No such file or directory is found`. 
## How to Play
* Arrow keys to rotate and move the tetromino.
* ``q`` to quit, ``r`` to restart.

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[GNU v3](https://www.gnu.org/licenses/gpl-3.0.en.html)