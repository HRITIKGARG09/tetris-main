# Troubleshoot (Linux Users)
If you're unable to run/build the files,follow the steps:
* Replace provided `Makefile` here with Makefile in tetris folder
* Run `linux.sh`