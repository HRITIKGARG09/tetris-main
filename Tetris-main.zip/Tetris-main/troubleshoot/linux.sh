# Run this if setup isn't working

sudo apt install cmake libglfw3-dev libglfw3 libglew-dev libglew2.1 libfreetype-dev libfreetype6 libfreetype6-dev libglm-dev libglapi-mesa libgles-dev
cd ../tetris && make

echo "----ENJOY GAME IS YOURS----"