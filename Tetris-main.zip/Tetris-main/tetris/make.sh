g++ -M Tetris.cpp Game.cpp Board.cpp Tetromino.cpp include/InitShader.cpp > depend
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -c -o Tetris.o Tetris.cpp
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -c -o Game.o Game.cpp
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -c -o Board.o Board.cpp
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -c -o Tetromino.o Tetromino.cpp
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -c -o include/InitShader.o include/InitShader.cpp
g++ -O0 -g -Wall -pedantic -Wno-unused-result -DGL_GLEXT_PROTOTYPES -I. -I../project/include/ -Iinclude/ -L../project/lib Tetris.o Game.o Board.o Tetromino.o include/InitShader.o -o tetris -lGL -lglut -lGLEW -lXext -lX11 -lm