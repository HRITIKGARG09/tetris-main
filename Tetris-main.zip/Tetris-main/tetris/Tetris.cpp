#include "Game.h"

int main(int argc, char **argv)
{
    Game game;
    game.run(argc, argv);
    
    return 0;
}
