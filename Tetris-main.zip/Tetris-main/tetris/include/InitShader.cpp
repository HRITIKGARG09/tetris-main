#include "Angel.h"

// // Initialize the window
namespace Angel {

// Create a NULL-terminated string by reading the provided file
static char*
readShaderSource(const char* shaderFile)
{
	// Open the file
    FILE* fp = fopen(shaderFile, "r");
	// Exit if the file couldn't be opened
    if ( fp == NULL ) { return NULL; }
	// Create a buffer that will hold the current line of the file
    fseek(fp, 0L, SEEK_END);
	// Get the file size
    long size = ftell(fp);

	// Allocate a buffer that will hold the source of the shader, and exit if the buffer couldn't be allocated
    fseek(fp, 0L, SEEK_SET);
	// Allocate a buffer that will hold the source of the shader
    char* buf = new char[size + 1];
	// Exit if the buffer couldn't be allocated
    fread(buf, 1, size, fp);

	// Close the file
    buf[size] = '\0';
    fclose(fp);

    return buf;
}


// Create a GLSL program object from vertex and fragment shader files
GLuint
InitShader(const char* vShaderFile, const char* fShaderFile)
{
	// Allocate a program object
    struct Shader {
	const char*  filename;
	GLenum       type;
	GLchar*      source;
    }  shaders[2] = {
	{ vShaderFile, GL_VERTEX_SHADER, NULL },
	{ fShaderFile, GL_FRAGMENT_SHADER, NULL }
    };

	// Load the shader source
    GLuint program = glCreateProgram();
    

	// Loop over the shaders
    for ( int i = 0; i < 2; ++i ) {
	Shader& s = shaders[i];
	s.source = readShaderSource( s.filename );
	if ( shaders[i].source == NULL ) {
	    std::cerr << "Failed to read " << s.filename << std::endl;
	    exit( EXIT_FAILURE );
	}
	// Create a shader object
	GLuint shader = glCreateShader( s.type );
	// Set the source code in the shader object
	glShaderSource( shader, 1, (const GLchar**) &s.source, NULL );
	// Compile the shader
	glCompileShader( shader );

	GLint  compiled;
	// Check the compile status
	glGetShaderiv( shader, GL_COMPILE_STATUS, &compiled );

	// If the compilation failed, print the error log
	if ( !compiled ) {
	    std::cerr << s.filename << " failed to compile:" << std::endl;
	    GLint  logSize;
	    glGetShaderiv( shader, GL_INFO_LOG_LENGTH, &logSize );
	    char* logMsg = new char[logSize];
	    glGetShaderInfoLog( shader, logSize, NULL, logMsg );
	    std::cerr << logMsg << std::endl;
	    delete [] logMsg;

	    exit( EXIT_FAILURE );
	}

	delete [] s.source;

	// NOTE: we don't need to keep a copy of the shader objects, since
	// they are already attached to the program object.
	glAttachShader( program, shader );
    }

    /* link  and error check */
    glLinkProgram(program);

	// Check the link status
    GLint  linked;
    glGetProgramiv( program, GL_LINK_STATUS, &linked );

	// If the linking failed, print the error log
    if ( !linked ) {
	std::cerr << "Shader program failed to link" << std::endl;
	GLint  logSize;
	glGetProgramiv( program, GL_INFO_LOG_LENGTH, &logSize);
	char* logMsg = new char[logSize];
	glGetProgramInfoLog( program, logSize, NULL, logMsg );
	std::cerr << logMsg << std::endl;
	delete [] logMsg;

	exit( EXIT_FAILURE );
    }

    /* use program object */
    glUseProgram(program);

    return program;
}

}  // Close namespace Angel block
