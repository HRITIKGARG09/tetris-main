#include "Game.h"
#include "constants.h"

// Get the system time
#include <sys/time.h>
#include <unistd.h>

// Prototypes of score functions
#include <iostream>

Game *Game::singleton = NULL;

void Game::run(int argc, char **argv)
{
    // Initialize the window
    singleton = this;
    timeval t;
    gettimeofday(&t, NULL);

    srand((unsigned)(t.tv_sec * 1000 + t.tv_usec));

    tetromino.game = singleton;
    tetromino.board = &board;
    
    glutInit(&argc, argv);

#ifdef __APPLE__
    // This is needed on the Mac to get the window to show up
    glutInitDisplayMode(GLUT_3_2_CORE_PROFILE | GLUT_RGBA | GLUT_DOUBLE);
#else
    // This is needed on the Linux to get the window to show up
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
#endif
    // Create the window
    glutInitWindowSize(340, 600);
    glutCreateWindow("Tetris");

#ifndef __APPLE__
    glewInit();
#endif

    // Initialize the game

    reset();
    init();
    // loops until the game is over

    // Initialize the OpenGL rendering properties

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutIdleFunc(idle);

    // Enter the glut event loop
    glutMainLoop();
}

void Game::init()
{
    vec2 points[kTotalPoints];
    // Initialize the points of the tetromino
    for (int i = 0; i < kNumOfHLines; ++i)
    {
        // Horizontal lines
        points[i * 2] = vec2(-W, -H + BLOCK_H * i);
        points[i * 2 + 1] = vec2(W, -H + BLOCK_H * i);
    }
    for (int i = 0; i < kNumOfVLines; ++i)
    {
        // Vertical lines
        points[kNumOfHPoints + i * 2] = vec2(-W + BLOCK_W * i, -H);
        points[kNumOfHPoints + i * 2 + 1] = vec2(-W + BLOCK_W * i, H);
    }

    vec4 colors[kTotalPoints];
    // Initialize the colors of the tetromino
    for (int i = 0; i < kNumOfHPoints + kNumOfVPoints; ++i)
    {
        colors[i] = vec4(1.0, 1.0, 1.0, 1.0); // pink
    }

    // Initialize the tetromino
    GLuint vaoID;
    // Create a vertex array object
    glGenVertexArrays(1, &vaoID);
    // Set it as the current vertex array object
    glBindVertexArray(vaoID);

    // Initialize the buffer for the points
    GLuint vboID;
    // Generate a buffer object
    glGenBuffers(1, &vboID);
    // Set the current state to focus on the buffer object
    glBindBuffer(GL_ARRAY_BUFFER, vboID);
    // Upload the data to the GPU
    glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);
    // Upload the points
    glBufferSubData(GL_ARRAY_BUFFER, 0, kTotalPoints * sizeof(vec2), points);
    // Upload the colors
    glBufferSubData(GL_ARRAY_BUFFER, kColorsOffset, sizeof(colors), colors);

    /**
     * @brief Shaders were initialised here
     * @param vertex_shader
     * @param fragment_shader
     * 
     */

    // Initialize the shaders
    GLuint program = InitShader("vshader.glsl", "fshader.glsl");
    // Set the shader program
    GLuint vPosition = glGetAttribLocation(program, "vPosition");
    // Enable the attribute
    glEnableVertexAttribArray(vPosition);
    // Specify the layout of the data
    glVertexAttribPointer(vPosition, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    // Initialize the buffer for the colors
    GLuint vColor = glGetAttribLocation(program, "vColor");
    // // Enable the attribute
    glEnableVertexAttribArray(vColor);
    // The offset is the (total) size of the points
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(kColorsOffset));

    // Backgound Color
    // Olive Green - .37, .62, .50, 0.1
    glClearColor(.37, .62, .50, 0.1);
}

void Game::reset()
{
    // Initialize the board
    tetromino.interval = kDefaultInterval;
    tetromino.reset();
    board.reset();
    is_game_over = false;
}

void Game::display()
{
    if (singleton->is_game_over)
    {
        // Game over
        std::cout << "Score is " << singleton->board.current_score << std::endl;
        exit(EXIT_SUCCESS);
    }
    else
    {
        // Draw the board
        singleton->tetromino.write_buffer();
        singleton->board.write_buffer();
        // Draw the tetromino
        glClear(GL_COLOR_BUFFER_BIT);
        // Draw the board
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        // Draw the tetromino
        glEnable(GL_CULL_FACE);

        // draw grids
        glDrawArrays(GL_LINES, 0, kNumOfHPoints + kNumOfVPoints);

        // draw current tetromino
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays(GL_TRIANGLE_STRIP, kBeginTetrominoPoints, kNumOfTetrominoPoints);

        // draw bottom blocks
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays(GL_TRIANGLE_STRIP, kBeginBoardPoints, singleton->board.num_of_points);
    }
    // Swap the buffers
    glutSwapBuffers();
}

void Game::keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        singleton->tetromino.left();
        break;
    case GLUT_KEY_RIGHT:
        singleton->tetromino.right();
        break;
    case GLUT_KEY_UP:
        singleton->tetromino.rotate();
        break;
    case GLUT_KEY_DOWN:
        singleton->tetromino.down();
        break;
    case 'r':
    case 'R':
        singleton->reset();
        break;
    case 'q':
    case 'Q':
    case kKeyCodeESC:
    case kKeyCodeESC2:
        exit(EXIT_SUCCESS);
        break;
    }
}
/**
 * @brief Special keys
 * 
 * @param key 
 * @param x 
 * @param y 
 */
void Game::special(int key, int x, int y)
{
    singleton->keyboard(key, x, y);
}

void Game::idle()
{
    // Update the game after a certain interval
    usleep(20);
    glutPostRedisplay();
}

void Game::game_over()
{
    // Check if Game over
    is_game_over = true;
}
